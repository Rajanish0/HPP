#!/usr/bin/env python
# coding: utf-8

# In[1]:


from flask import Flask, request, jsonify
import numpy as np
import pickle

app = Flask(__name__)

# Load the trained model
with open("model/house_price_model.pkl", "rb") as f:
    model = pickle.load(f)

@app.route("/")
def home():
    return "🏠 House Price Prediction API"

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    features = np.array([[df['lotsize'], df['bedrooms'], df['bathrms'],df["stories"],df["garagepl"],df["driveway_yes"],df["recroom_yes"],df["fullbase_yes"],df["gashw_yes"],df["airco_yes"]]])
    prediction = model.predict(features)[0]
    return jsonify({"predicted_price": round(prediction, 2)})

if __name__ == "__main__":
    app.run(debug=True)


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




