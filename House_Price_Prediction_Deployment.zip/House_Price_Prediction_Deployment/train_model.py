#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Importing necessary libraries
# pd is the alias for pandas
import pandas as pd
# np is the alias for numpy
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import pickle
import os


# # Applying Linear Regression on Housing Dataset

# In[3]:


# Loading Dataset
df = pd.read_csv("Housing.csv")
# Show top 5 rows
df.head()


# In[5]:


x=df.iloc[::,2::]
x


# In[7]:


c=1
sns.set(style="darkgrid")
plt.figure(figsize=(15,8))
plt.subplots_adjust(hspace=0.5)
plt.subplots_adjust(wspace=0.8)
for i in x:
    plt.subplot(2,5,c)
    sns.countplot(x=df[i],data=df)
    plt.xlabel(i)
    c+=1


# In[9]:


# Pre-Processing Data by using pandas get_dummies() method
dum_df = pd.get_dummies(df, drop_first=True)


# In[11]:


dum_df=dum_df.replace("yes",1).replace("no",1).replace(True,1).replace(False,0)


# In[13]:


# Seperating Output and Input VariablesX = dum_df.iloc[:,1:11]
X = dum_df.iloc[:,1:11]
y = dum_df.iloc[:,0]


# In[15]:


X


# In[17]:


# Importing train_test_split from sklearn.model_selection to split the data in to train and test sets
from sklearn.model_selection import train_test_split 
X_train, X_test, y_train, y_test = train_test_split(X, y,test_size = 0.3, random_state=2022)


# ## LinearRegression

# In[19]:


# Importing LinearRegression from sklearn.linear_model
from sklearn.linear_model import LinearRegression
# Initializing LinearRegression()
model = LinearRegression()
# Fittting the regressor on train data
model.fit(X_train, y_train)


# In[21]:


# Printing regressor coefficient
print(model.coef_)
# Printing regressor intercept
print(model.intercept_)


# In[23]:


# Predicting Output on test data
y_pred = model.predict(X_test)


# In[25]:


# Imorting mean_squared_error,mean_absolute_error,r2_score from sklearn.metrics
from sklearn.metrics import mean_squared_error,mean_absolute_error,r2_score
# Printing Mean Squared Error (MSE)
print("MSE => ", np.sqrt( mean_squared_error(y_test, y_pred)))
# Printing Mean Absolute Error (MAE)
print("MAE => ",mean_absolute_error(y_test, y_pred))
# Printing R2 score
print("R2 Score => ",r2_score(y_test, y_pred))


# ### Applying K-Fold CV 

# #### Comparing R2 score 
# - R2 Score for Regression => 0.618
# - R2 Score for Regression with KFold CV=> 0.64
# 
# So from above we can conclude that the R2 score for the Linear Regression using KFold CV is better than plain Linear Regression
# 

# In[29]:


# Create model folder
os.makedirs("model", exist_ok=True)

# Save the model
with open("model/house_price_model.pkl", "wb") as f:
    pickle.dump(model, f)

print("✅ Model trained and saved to model/house_price_model.pkl")


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




